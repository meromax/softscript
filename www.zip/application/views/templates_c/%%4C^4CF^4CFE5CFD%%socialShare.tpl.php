<?php /* Smarty version 2.6.18, created on 2014-01-16 13:17:27
         compiled from socialShare.tpl */ ?>
<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style ">
    <a class="addthis_counter addthis_pill_style"></a>
</div>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-52d79d513aad385e"></script>
<!-- AddThis Button END -->