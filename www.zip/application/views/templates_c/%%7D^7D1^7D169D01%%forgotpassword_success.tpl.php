<?php /* Smarty version 2.6.18, created on 2013-11-03 22:06:32
         compiled from login/forgotpassword_success.tpl */ ?>
<div class="staticPageBox">
    <div class="pageTitle">Восстановление пароля</div>
    <div class="pageText">
    Новый пароль был отправлен на ваш почтовый ящик.
    </div>
</div>

<?php echo '
<script type="text/javascript">
    setTimeout(function () { document.location.href=\'/loginpage.html\'; }, 5000);
</script>
'; ?>

