<?php /* Smarty version 2.6.18, created on 2011-11-23 18:13:44
         compiled from registration/reg_complete.tpl */ ?>
<div class="cont_sr">
	<div class="cont_s_pos">
		<div class="gl_block">
			<div class="t_line"><i class="t_l"></i><i class="t_r"></i></div>
			<div class="gl_block_pos">
					<h1><?php echo $this->_tpl_vars['frontendLangParams']['TITLE__REGISTRATION_COMPLETED']; ?>
</h1>
			</div>
			<i class="b_l"></i><i class="b_r"></i>
		</div>
	</div>
</div>
<?php echo '
<script type="text/javascript">
	setTimeout(function () { document.location.href=\'/\'; }, 5000);
</script>
'; ?>