<?php /* Smarty version 2.6.18, created on 2014-02-05 20:27:55
         compiled from admin/deals/tab_datatime.tpl */ ?>
<div class="control-group">
    <label class="control-label">Default Datetimepicker</label>
    <div class="controls">
        <div class="input-append date form_datetime">
            <input size="16" type="text" value="" readonly class="m-wrap">
            <span class="add-on"><i class="icon-calendar"></i></span>
        </div>
    </div>
</div>

<div class="control-group">
    <label class="control-label">Default Datetimepicker</label>
    <div class="controls">
        <div class="input-append date form_datetime">
            <input size="16" type="text" value="" readonly class="m-wrap">
            <span class="add-on"><i class="icon-calendar"></i></span>
        </div>
    </div>
</div>

<div class="control-group">
    <label class="control-label">Default Datetimepicker</label>
    <div class="controls">
        <div class="input-append date form_datetime">
            <input size="16" type="text" value="" readonly class="m-wrap">
            <span class="add-on"><i class="icon-calendar"></i></span>
        </div>
    </div>
</div>

<div class="control-group">
    <label class="control-label">Default Datetimepicker</label>
    <div class="controls">
        <div class="input-append date form_datetime">
            <input size="16" type="text" value="" readonly class="m-wrap">
            <span class="add-on"><i class="icon-calendar"></i></span>
        </div>
    </div>
</div>