<?php /* Smarty version 2.6.18, created on 2014-02-25 11:45:05
         compiled from admin/footer.tpl */ ?>
    </div>
    <!-- END PAGE -->

</div>
<!-- END CONTAINER -->

<div class="footer">
    <div class="footer-inner">
        2014 &copy; SoftScript
    </div>
    <div class="footer-tools">
			<span class="go-top">
			<i class="icon-angle-up"></i>
			</span>
    </div>
</div>
<!-- start for modal box layout -->
<div class="modal-backdrop" style="display: none;"></div>
<!-- end for modal box layout -->

</body>
</html>