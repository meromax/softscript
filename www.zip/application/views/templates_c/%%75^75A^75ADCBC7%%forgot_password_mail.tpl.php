<?php /* Smarty version 2.6.18, created on 2013-11-03 22:06:31
         compiled from login/forgot_password_mail.tpl */ ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Восстановление пароля</title>
</head>

<body>
<p>Здравствуйте, <b><?php echo $this->_tpl_vars['email']; ?>
.</b><br />
<p>Ваш новый пароль: <b><?php echo $this->_tpl_vars['password']; ?>
</b><br /><br />

<p>С наилучшими пожеланиями<br /><a href="http://mirzagorodom.ru" target="_blank">Mirzagorodom.ru</a>

</body>
</html>