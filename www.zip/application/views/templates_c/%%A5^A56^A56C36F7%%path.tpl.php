<?php /* Smarty version 2.6.18, created on 2013-06-30 06:28:08
         compiled from path.tpl */ ?>
<div style="padding: 0px 0px 0px 0px;" class="news_items2"><?php echo $this->_tpl_vars['path']; ?>
</div>