<?php /* Smarty version 2.6.18, created on 2014-02-07 18:21:04
         compiled from social.tpl */ ?>
                                    
                                
                
                
                                                    
                                        
<script type="text/javascript" src="//yandex.st/share/share.js" charset="utf-8"></script>
<div class="yashare-auto-init" data-yashareL10n="ru" data-yashareType="button" data-yashareQuickServices="vkontakte,twitter,lj"></div>

