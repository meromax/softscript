<?php /* Smarty version 2.6.18, created on 2014-01-23 12:32:38
         compiled from profile/products_meta.tpl */ ?>
<div class="underlined push-down-20">
    <h3><span class="light">Информация, которая необходима для</span> поисковисков</h3>
</div>

<p class="push-down-10">
    <label for="author">МЕТА заколовок:</label>
    <input type="text" id="meta_title" name="meta_title" class="span7" placeholder="Введите МЕТА название вашего товара здесь...">
</p>

<p class="push-down-10">
    <label for="author">МЕТА ключевые слова:</label>
    <input type="text" id="meta_keywords" name="meta_keywords" class="span7" placeholder="Введите МЕТА ключевые слова вашего товара здесь...">
</p>

<p class="push-down-10">
    <label for="author">МЕТА описание:</label>
    <input type="text" id="meta_description" name="meta_description" class="span7" placeholder="Введите МЕТА описание вашего товара здесь...">
</p>