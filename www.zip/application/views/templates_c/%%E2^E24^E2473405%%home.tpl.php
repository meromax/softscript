<?php /* Smarty version 2.6.18, created on 2014-01-27 13:18:30
         compiled from admin/home.tpl */ ?>
<?php echo $this->_tpl_vars['warningBlock']; ?>
             