<?php /* Smarty version 2.6.18, created on 2014-01-23 12:32:38
         compiled from profile/products_additional.tpl */ ?>
<div class="underlined push-down-20">
    <h3><span class="light">Дополнительная</span> информация</h3>
</div>

<p class="push-down-10">
    <label for="author">Вставка видео кода с youtube.com:</label>
    <textarea tabindex="4" id="video" name="video" rows="10" class="span7 ckeditor" placeholder="Вставьте код видео..."></textarea>
</p>

<p class="push-down-10">
    <label for="author">Дополнительная информация:</label>
    <textarea tabindex="4" id="addinfo2" name="addinfo2" rows="10" class="span7 ckeditor" placeholder="Вставьте какой-нибудь текст..."></textarea>
</p>