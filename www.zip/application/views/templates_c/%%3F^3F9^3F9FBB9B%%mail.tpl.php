<?php /* Smarty version 2.6.18, created on 2012-03-14 11:26:52
         compiled from orders/mail.tpl */ ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Вы оформили заказ на сайте http://www.stop-varikoz.ru</title>
</head>

<body>
<table cellpadding="0" cellspacing="0" width="60%">
<tr>
	<td align="left" valign="top">
        Здравствуйте!<br />
        Администрация сайта <a href="http://www.stop-varikoz.ru">http://www.stop-varikoz.ru</a> поздравляет Вас с успешным оформлением заказа!<br />
        Стоимость Вашего заказа:<?php echo $this->_tpl_vars['total_price']; ?>
.<br />
        В ближайшее время с Вами свяжутся для уточнения контактных данных.<br />
        Это письмо было сгенерированоавтоматически и не требует ответа.
        По всем вопросам и предложениям просьба обращаться по адресу: info@stop-varikoz.ru.
        С Уважением, администрация сайта: <a href="http://www.stop-varikoz.ru">http://www.stop-varikoz.ru</a>
	</td>
</tr>
</table>
</body>
</html>