<?php /* Smarty version 2.6.18, created on 2014-01-27 14:02:30
         compiled from admin/navigation.tpl */ ?>
<ul class="page-sidebar-menu">
    <li>
        <div class="sidebar-toggler hidden-phone"></div>
    </li>
    <li>
                                                                &nbsp;
    </li>
    <li class="start active ">
        <a href="/admin">
            <i class="icon-home"></i>
            <span class="title">Панель управления</span>
            <span class="selected"></span>
        </a>
    </li>
    <li class="">
        <a href="javascript:;">
            <i class="icon-cogs"></i>
            <span class="title">Layouts</span>
            <span class="arrow "></span>
        </a>
        <ul class="sub-menu">
            <li >
                <a href="layout_horizontal_sidebar_menu.html">
                    Horzontal & Sidebar Menu</a>
            </li>
            <li >
                <a href="layout_horizontal_menu1.html">
                    Horzontal Menu 1</a>
            </li>
            <li >
                <a href="layout_horizontal_menu2.html">
                    Horzontal Menu 2</a>
            </li>
            <li >
                <a href="layout_promo.html">
                    Promo Page</a>
            </li>
            <li >
                <a href="layout_email.html">
                    Email Templates</a>
            </li>
            <li >
                <a href="layout_ajax.html">
                    Content Loading via Ajax</a>
            </li>
            <li >
                <a href="layout_sidebar_closed.html">
                    Sidebar Closed Page</a>
            </li>
            <li >
                <a href="layout_blank_page.html">
                    Blank Page</a>
            </li>
            <li >
                <a href="layout_boxed_page.html">
                    Boxed Page</a>
            </li>
            <li >
                <a href="layout_boxed_not_responsive.html">
                    Non-Responsive Boxed Layout</a>
            </li>
        </ul>
    </li>
    <li class="last ">
        <a href="charts.html">
            <i class="icon-bar-chart"></i>
            <span class="title">Visual Charts</span>
        </a>
    </li>
</ul>