<?php /* Smarty version 2.6.18, created on 2013-11-04 03:13:42
         compiled from search/searchBox.tpl */ ?>
<form method="post" action="/search" name="search_form" id="search_form">
<div class="searchInputBox">
    <input type="text" name="search_input" id="search_input" placeholder="Введите поисковый запрос..." />
</div>
<div class="searchButtonBox">
    <a href="javascript:void(0);" id="searchBtn"><img src="/images/button-search.png" /></a>
</div>
</form>