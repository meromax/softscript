<?php /* Smarty version 2.6.18, created on 2013-05-27 05:22:05
         compiled from sections/template_section_page.tpl */ ?>
<div class="redGrayLine">
    <table cellpaddong="0" cellspacing="0" width="100%" height="38">
        <tbody><tr>
            <td class="redLine">&nbsp;</td>
            <td class="middleLine"></td>
            <td class="grayLine">&nbsp;</td>
        </tr>
        </tbody></table>
</div>

<div class="redGrayLine2">
    <div class="redLine">
        <div class="pageTitle3">Мебельный каталог</div>
    </div>
    <div class="grayLine">

    </div>
</div>

<div class="topTextBlock" style="min-height: 120px;">
    <div class="pageTitle">
        </div>
    <div class="leftNavigationBox">
        <div class="leftMenuBox leftBorderGray">
            <div class="navHeader">
                <a href="">Модульные наборы ( гостиные )</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
        </div>
        <div class="leftMenuBox leftBorderGray2">
            <div class="navHeader">
                <a href="">Модульные наборы ( гостиные )</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
        </div>
        <div class="leftMenuBox leftBorderGray">
            <div class="navHeader">
                <a href="">Модульные наборы ( гостиные )</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
        </div>
        <div class="leftMenuBox leftBorderGray2">
            <div class="navHeader">
                <a href="">Модульные наборы ( гостиные )</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
            <div class="navItem">
                <a href="">Areka</a>
            </div>
            <div class="navItem">
                <a href="">August</a>
            </div>
        </div>
    </div>

    <div class="rightProductsBox">
        <div class="productBox">
            <div class="prodTitle">
                <a href="">Спальня AUGUST</a>
            </div>
            <div class="prodImage">
                <a href="">
                    <img src="/images/prod-example1.png" />
                </a>
            </div>
            <div class="prodPrice">
                <div class="priceTitle">Цена:</div>
                <div class="priceValue">10034000</div>
                <div class="priceCurrency">руб.</div>
            </div>

            <div class="prodButtonBuy">
                <a href=""><img src="/images/button-buy.png" /></a>
            </div>
        </div>
        <div class="productBoxLast">
            <div class="prodTitle">
                <a href="">Спальня AUGUST</a>
            </div>
            <div class="prodImage">
                <a href="">
                    <img src="/images/prod-example1.png" />
                </a>
            </div>
            <div class="prodPrice">
                <div class="priceTitle">Цена:</div>
                <div class="priceValue">10034000</div>
                <div class="priceCurrency">руб.</div>
            </div>

            <div class="prodButtonBuy">
                <a href=""><img src="/images/button-buy.png" /></a>
            </div>
        </div>

        <div class="productBox">
            <div class="prodTitle">
                <a href="">Спальня AUGUST</a>
            </div>
            <div class="prodImage">
                <a href="">
                    <img src="/images/prod-example1.png" />
                </a>
            </div>
            <div class="prodPrice">
                <div class="priceTitle">Цена:</div>
                <div class="priceValue">10034000</div>
                <div class="priceCurrency">руб.</div>
            </div>

            <div class="prodButtonBuy">
                <a href=""><img src="/images/button-buy.png" /></a>
            </div>
        </div>
        <div class="productBoxLast">
            <div class="prodTitle">
                <a href="">Спальня AUGUST</a>
            </div>
            <div class="prodImage">
                <a href="">
                    <img src="/images/prod-example1.png" />
                </a>
            </div>
            <div class="prodPrice">
                <div class="priceTitle">Цена:</div>
                <div class="priceValue">10034000</div>
                <div class="priceCurrency">руб.</div>
            </div>

            <div class="prodButtonBuy">
                <a href=""><img src="/images/button-buy.png" /></a>
            </div>
        </div>

        <div class="productBox">
            <div class="prodTitle">
                <a href="">Спальня AUGUST</a>
            </div>
            <div class="prodImage">
                <a href="">
                    <img src="/images/prod-example1.png" />
                </a>
            </div>
            <div class="prodPrice">
                <div class="priceTitle">Цена:</div>
                <div class="priceValue">10034000</div>
                <div class="priceCurrency">руб.</div>
            </div>

            <div class="prodButtonBuy">
                <a href=""><img src="/images/button-buy.png" /></a>
            </div>
        </div>
        <div class="productBoxLast">
            <div class="prodTitle">
                <a href="">Спальня AUGUST</a>
            </div>
            <div class="prodImage">
                <a href="">
                    <img src="/images/prod-example1.png" />
                </a>
            </div>
            <div class="prodPrice">
                <div class="priceTitle">Цена:</div>
                <div class="priceValue">10034000</div>
                <div class="priceCurrency">руб.</div>
            </div>

            <div class="prodButtonBuy">
                <a href=""><img src="/images/button-buy.png" /></a>
            </div>
        </div>

        <div class="clearfix">
            <div class="paginator">
                <a href="/catalog/sec/avtosignalizacii/page/5"><div class="point">1</div></a>
                <div class="pointActive">2</div>
                <a href="/catalog/sec/avtosignalizacii/page/2"><div class="point">3</div></a>
                <a href="/catalog/sec/avtosignalizacii/page/3"><div class="point">4</div></a>
                <a href="/catalog/sec/avtosignalizacii/page/4"><div class="point">5</div></a>
                <a href="/catalog/sec/avtosignalizacii/page/5"><div class="point">6</div></a>
            </div>
        </div>


        <div class="sectionDescription">
            <p>
                Мебель,  заказанная  через Интернет-магазин, доставляется БЕСПЛАТНО до
                подъезда покупателя в пределах городов: Брест, Витебск, Гродно, Гомель, Барановичи, Могилев.
            </p>

            <p>
                Мебель,  заказанная  через Интернет-магазин, доставляется БЕСПЛАТНО до
                подъезда покупателя в пределах городов: Брест, Витебск, Гродно, Гомель, Барановичи, Могилев.
            </p>
        </div>

    </div>

    <div class="clearfix"></div>
</div>



                                                                                    
                                                                                                                

            
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
                

                    
                            
                
                
                
                