<?php /* Smarty version 2.6.18, created on 2014-01-20 16:33:36
         compiled from leftNavigation.tpl */ ?>
<div class="product_menu">

    <nav>
        <ul id="ddmenu">

            <li><a href="#">Локальные очистные сооружения</a></li>

            <li><a href="#" class="active">Локальные очистные сооружения</a>
                <ul>
                    <li><a href="#">Хозяйственно-бытовая канализация</a></li>
                    <li><a href="#">Хозяйственно-бытовая канализация</a></li>
                    <li><a href="#">Хозяйственно-бытовая канализация</a></li>
                    <li><a href="#">Хозяйственно-бытовая канализация</a></li>
                    <li><a href="#">Хозяйственно-бытовая канализация</a></li>
                </ul>
            </li>

        </ul>
    </nav>

</div>

                
                