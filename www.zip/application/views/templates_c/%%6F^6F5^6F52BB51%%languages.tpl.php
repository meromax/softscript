<?php /* Smarty version 2.6.18, created on 2011-08-29 22:50:26
         compiled from languages.tpl */ ?>
<div id="lbuttons">
	<a href="/en/about-company.html" class="lbt"><!-- --></a>
	<a href="/ru/about-company.html" class="lbt"><!-- --></a>
</div>